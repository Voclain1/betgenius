"""A robust, typed Python wrapper around the rclone command-line tool."""

from __future__ import annotations

from .exceptions import (
    EXIT_CODES,
    RcloneCommandError,
    RcloneError,
    RcloneNotFoundError,
)
from .models import Entry, RcloneResult, SizeResult, Stats
from .rclone import Rclone

__version__ = "2.0.0"

__all__ = [
    "Rclone",
    "RcloneResult",
    "SizeResult",
    "Stats",
    "Entry",
    "RcloneError",
    "RcloneNotFoundError",
    "RcloneCommandError",
    "EXIT_CODES",
    "__version__",
]
